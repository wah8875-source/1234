# 星海挑战者 · 宇宙 Quiz App

一个可直接部署到 Vercel 的网页版 Quiz App：

- 20 关挑战：每关 1 道单选题
- 宇宙星空风格背景（星点闪烁 + 流星）
- 答对特效（粒子爆散） / 答错提示（正确答案 + 解析）
- 最后一关结束显示总分，并可一键重来

## 本地运行

```bash
npm install
npm run dev
```

打开：http://localhost:3000

## 项目结构（关键部分）

```
src/
  app/
    layout.tsx        # 站点元信息 + 全局布局
    page.tsx          # 首页（背景 + QuizEngine）
    globals.css       # 星空主题 + 动画 + 组件辅助样式
  components/
    CosmicBackground.tsx
    quiz/
      QuizEngine.tsx  # 关卡流程 / 判定 / 总分
      ParticleBurst.tsx
  data/
    questions.ts      # 20 关题库（可自行替换）
```

## 部署到 Vercel（最简单）

1. 把此项目推到 GitHub（或直接上传到 Vercel）
2. 在 Vercel New Project 选择该仓库
3. Framework 选择 Next.js（Vercel 通常会自动识别）
4. Build/Output 配置保持默认即可（无需 dist/client、无需 vercel.json）

部署完成后，访问你在 Vercel 上的域名即可。
