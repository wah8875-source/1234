export type QuizQuestion = {
  id: number;
  title: string;
  options: string[];
  answerIndex: number;
  explanation: string;
};

// 20 关：每关 1 题（单选）
export const QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    title: "太阳系中体积最大的行星是？",
    options: ["地球", "木星", "火星", "金星"],
    answerIndex: 1,
    explanation: "木星是太阳系中体积和质量最大的行星。",
  },
  {
    id: 2,
    title: "光从太阳到地球大约需要多久？",
    options: ["8 分钟左右", "8 秒左右", "8 小时左右", "1 天左右"],
    answerIndex: 0,
    explanation: "日地距离约 1 AU，光行进时间约 8 分 20 秒。",
  },
  {
    id: 3,
    title: "我们所在的星系名称是？",
    options: ["仙女座星系", "银河系", "三角座星系", "大麦哲伦云"],
    answerIndex: 1,
    explanation: "太阳系位于银河系内。",
  },
  {
    id: 4,
    title: "“红色星球”通常指的是哪颗行星？",
    options: ["水星", "火星", "土星", "海王星"],
    answerIndex: 1,
    explanation: "火星表面富含氧化铁，呈现红色。",
  },
  {
    id: 5,
    title: "地球大气中含量最多的气体是？",
    options: ["氧气", "二氧化碳", "氮气", "氩气"],
    answerIndex: 2,
    explanation: "地球大气约 78% 为氮气。",
  },
  {
    id: 6,
    title: "月球产生“盈亏”（月相变化）的主要原因是？",
    options: ["月球自转", "月球公转导致受光面变化", "地球影子遮挡月球", "太阳亮度变化"],
    answerIndex: 1,
    explanation: "月相是我们看到的月球受光部分随相对位置改变而变化。",
  },
  {
    id: 7,
    title: "哪一种天体以强引力著称，连光也难以逃逸？",
    options: ["脉冲星", "白矮星", "黑洞", "彗星"],
    answerIndex: 2,
    explanation: "黑洞的逃逸速度超过光速，因此光也无法直接逃逸。",
  },
  {
    id: 8,
    title: "流星雨通常与哪类天体的轨道碎屑有关？",
    options: ["行星", "彗星", "恒星", "星云"],
    answerIndex: 1,
    explanation: "彗星留下的尘埃碎屑进入地球大气形成流星雨。",
  },
  {
    id: 9,
    title: "下列哪项最能描述“星等”在天文学中的含义？",
    options: ["温度等级", "亮度（视亮度）等级", "质量等级", "距离等级"],
    answerIndex: 1,
    explanation: "星等用于表示天体的亮度，数值越小通常越亮。",
  },
  {
    id: 10,
    title: "离地球最近的恒星（不含太阳）是？",
    options: ["比邻星", "天狼星", "织女星", "参宿四"],
    answerIndex: 0,
    explanation: "比邻星是半人马座α星系统的一部分，是离太阳最近的恒星。",
  },
  {
    id: 11,
    title: "星座的本质更接近于：",
    options: ["真实相连的恒星群", "人为划分的天空区域与图案", "同一年龄的恒星团", "同一距离的恒星集合"],
    answerIndex: 1,
    explanation: "星座是人类根据视觉图案对天空区域进行的划分。",
  },
  {
    id: 12,
    title: "“天王星”最显著的自转特征是？",
    options: ["自转极慢", "自转方向与其他行星相反", "自转轴几乎“躺着”转", "没有自转"],
    answerIndex: 2,
    explanation: "天王星自转轴倾角约 98°，像“躺着”绕太阳公转。",
  },
  {
    id: 13,
    title: "哈勃定律主要揭示了什么现象？",
    options: ["恒星的演化规律", "宇宙在膨胀", "黑洞的吸积过程", "行星的形成机制"],
    answerIndex: 1,
    explanation: "星系退行速度与距离成正比，支持宇宙膨胀的结论。",
  },
  {
    id: 14,
    title: "“光年”在天文学中是一个什么单位？",
    options: ["时间", "速度", "距离", "亮度"],
    answerIndex: 2,
    explanation: "光年是光在真空中一年走过的距离。",
  },
  {
    id: 15,
    title: "以下哪种望远镜主要通过接收无线电波观测天体？",
    options: ["射电望远镜", "折射望远镜", "反射望远镜", "双筒望远镜"],
    answerIndex: 0,
    explanation: "射电望远镜接收无线电波段信号。",
  },
  {
    id: 16,
    title: "国际空间站（ISS）大致位于地表上空多少公里？",
    options: ["约 40 km", "约 400 km", "约 4,000 km", "约 40,000 km"],
    answerIndex: 1,
    explanation: "ISS 轨道高度通常在 400 km 左右。",
  },
  {
    id: 17,
    title: "“极光”最直接与哪种相互作用有关？",
    options: ["火山喷发与大气", "太阳风粒子与地球磁场/大气", "潮汐力与海洋", "彗星尾与太阳光"],
    answerIndex: 1,
    explanation: "太阳风粒子在磁场引导下进入高层大气并激发发光。",
  },
  {
    id: 18,
    title: "太阳的主要能量来源是？",
    options: ["燃烧", "核裂变", "核聚变", "放射性衰变"],
    answerIndex: 2,
    explanation: "太阳核心通过氢核聚变为氦释放能量。",
  },
  {
    id: 19,
    title: "“超新星爆发”通常发生在恒星演化的哪个阶段？",
    options: ["诞生初期", "稳定主序期", "生命末期", "恒星不会爆发"],
    answerIndex: 2,
    explanation: "大质量恒星或特定双星系统在演化末期可能发生超新星爆发。",
  },
  {
    id: 20,
    title: "最后一关：如果你在深空中看到某星系红移更强，通常意味着？",
    options: ["它更冷", "它更亮", "它离我们更远且远离更快", "它更靠近我们"],
    answerIndex: 2,
    explanation: "宇宙膨胀导致更远的星系退行速度更大，红移通常更强。",
  },
];

