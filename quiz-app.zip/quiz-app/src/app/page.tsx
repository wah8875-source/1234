import CosmicBackground from "@/components/CosmicBackground";
import QuizEngine from "@/components/quiz/QuizEngine";

export default function Home() {
  return (
    <div className="relative flex min-h-[100svh] flex-col">
      <CosmicBackground />

      <main className="mx-auto flex w-full max-w-3xl flex-1 flex-col items-stretch px-5 py-10 sm:px-8 sm:py-14">
        <div className="mb-6">
          <p className="text-sm text-white/70">宇宙星空 Quiz · 20 关挑战</p>
          <h1 className="mt-2 text-2xl font-semibold tracking-tight text-white sm:text-3xl">
            星海挑战者
          </h1>
          <p className="mt-2 text-sm leading-6 text-white/60">
            每关 1 题，答对自动进入下一关；答错会提示正确答案，你可手动进入下一关。
          </p>
        </div>

        <QuizEngine />

        <footer className="mt-8 text-xs text-white/50">
          <p>提示：本项目为 Next.js App Router，可直接部署到 Vercel。</p>
        </footer>
      </main>
    </div>
  );
}
