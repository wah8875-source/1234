"use client";

import { useMemo, useState } from "react";
import { QUESTIONS } from "@/data/questions";
import ParticleBurst from "./ParticleBurst";

type AnswerStatus = "idle" | "correct" | "wrong";

export default function QuizEngine() {
  const total = QUESTIONS.length;

  const [level, setLevel] = useState(0); // 0-based
  const [score, setScore] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [status, setStatus] = useState<AnswerStatus>("idle");
  const [locked, setLocked] = useState(false);
  const [shake, setShake] = useState(false);
  const [burstKey, setBurstKey] = useState(0);

  const question = QUESTIONS[level];

  const correctAnswerText = useMemo(() => {
    if (!question) return "";
    return question.options[question.answerIndex];
  }, [question]);

  const isSummary = level >= total;

  function resetForNext() {
    setSelected(null);
    setStatus("idle");
    setLocked(false);
    setShake(false);
  }

  function next() {
    resetForNext();
    setLevel((prev) => prev + 1);
  }

  function restart() {
    setLevel(0);
    setScore(0);
    resetForNext();
  }

  function onPick(optionIndex: number) {
    if (!question || locked) return;

    setSelected(optionIndex);
    setLocked(true);

    const isCorrect = optionIndex === question.answerIndex;
    if (isCorrect) {
      setStatus("correct");
      setScore((s) => s + 1);
      setBurstKey(Date.now());

      // 答对：短暂特效后自动进入下一关/结算
      window.setTimeout(() => {
        if (level === total - 1) {
          setLevel(total); // 进入结算页
        } else {
          next();
        }
      }, 900);
      return;
    }

    // 答错：给提示，手动进入下一关
    setStatus("wrong");
    setShake(true);
    window.setTimeout(() => setShake(false), 450);
  }

  if (isSummary) {
    return (
      <section className="quiz-card">
        <header className="mb-6">
          <p className="text-sm text-white/70">挑战结束</p>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight">
            你的总分：{score} / {total}
          </h1>
        </header>

        <div className="space-y-3 text-white/80">
          <p>
            {score === total
              ? "满分！你已经可以在星海里导航了。"
              : score >= Math.ceil(total * 0.7)
                ? "表现很棒！再冲几题就接近满分了。"
                : "不错的开始！再来一轮会更熟练。"}
          </p>
        </div>

        <div className="mt-8 flex flex-col gap-3 sm:flex-row">
          <button className="btn-primary" onClick={restart}>
            再来一次
          </button>
          <a className="btn-ghost" href="https://vercel.com/new" target="_blank" rel="noreferrer">
            部署到 Vercel
          </a>
        </div>
      </section>
    );
  }

  return (
    <section
      className={[
        "quiz-card relative",
        status === "correct" ? "ring-2 ring-cyan-300/70 shadow-cyan-500/20" : "",
        shake ? "animate-shake" : "",
      ].join(" ")}
    >
      {status === "correct" ? <ParticleBurst burstKey={burstKey} /> : null}

      <header className="flex items-start justify-between gap-4">
        <div>
          <p className="text-sm text-white/70">
            第 <span className="tabular-nums">{level + 1}</span> / {total} 关
          </p>
          <h1 className="mt-2 text-xl font-semibold leading-snug">{question.title}</h1>
        </div>
        <div className="text-right">
          <p className="text-sm text-white/70">当前得分</p>
          <p className="mt-1 text-2xl font-semibold tabular-nums">{score}</p>
        </div>
      </header>

      <div className="mt-6 grid gap-3">
        {question.options.map((opt, i) => {
          const isPicked = selected === i;
          const isCorrect = i === question.answerIndex;

          const showResult = locked && status !== "idle";
          const tone =
            showResult && isCorrect
              ? "border-emerald-300/60 bg-emerald-400/15"
              : showResult && isPicked && !isCorrect
                ? "border-rose-300/60 bg-rose-400/15"
                : "border-white/15 bg-white/5 hover:bg-white/10";

          return (
            <button
              key={opt}
              className={`option-btn ${tone}`}
              onClick={() => onPick(i)}
              disabled={locked}
            >
              <span className="option-dot" aria-hidden />
              <span className="text-left">{opt}</span>
            </button>
          );
        })}
      </div>

      <div className="mt-6 min-h-10">
        {status === "correct" ? (
          <p className="text-sm text-cyan-200/90">答对了！进入下一关…</p>
        ) : null}
        {status === "wrong" ? (
          <div className="space-y-1 text-sm text-white/80">
            <p className="text-rose-200/90">答错了。</p>
            <p>
              正确答案：<span className="font-semibold text-white">{correctAnswerText}</span>
            </p>
            <p className="text-white/60">{question.explanation}</p>
          </div>
        ) : null}
      </div>

      <footer className="mt-6 flex items-center justify-between gap-3">
        <div className="h-2 flex-1 overflow-hidden rounded-full bg-white/10">
          <div
            className="h-full rounded-full bg-gradient-to-r from-cyan-300/70 to-fuchsia-300/70 transition-[width] duration-500"
            style={{ width: `${((level + 1) / total) * 100}%` }}
          />
        </div>

        <button
          className="btn-ghost shrink-0 disabled:opacity-40"
          onClick={() => {
            if (level === total - 1) setLevel(total);
            else next();
          }}
          disabled={status !== "wrong"}
        >
          下一关
        </button>
      </footer>
    </section>
  );
}

