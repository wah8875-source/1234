"use client";

import type { CSSProperties } from "react";
import { useMemo } from "react";

type Particle = {
  id: number;
  dx: number;
  dy: number;
  delay: number;
  size: number;
  opacity: number;
};

function rand(min: number, max: number) {
  return Math.random() * (max - min) + min;
}

export default function ParticleBurst({ burstKey }: { burstKey: number }) {
  // 每次 burstKey 改变就重新生成粒子
  const particles = useMemo<Particle[]>(() => {
    // 使用 burstKey 作为“变化信号”，无需真正种子随机即可达到效果
    void burstKey;
    return Array.from({ length: 18 }).map((_, i) => ({
      id: i,
      dx: rand(-140, 140),
      dy: rand(-120, 120),
      delay: rand(0, 120),
      size: rand(6, 14),
      opacity: rand(0.7, 1),
    }));
  }, [burstKey]);

  return (
    <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
      {particles.map((p) => (
        <span
          // eslint-disable-next-line react/no-array-index-key
          key={`${burstKey}-${p.id}`}
          className="particle"
          style={
            {
              "--dx": `${p.dx}px`,
              "--dy": `${p.dy}px`,
              "--delay": `${p.delay}ms`,
              "--size": `${p.size}px`,
              "--opacity": p.opacity,
            } as CSSProperties
          }
        />
      ))}
    </div>
  );
}
