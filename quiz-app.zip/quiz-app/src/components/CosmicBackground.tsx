export default function CosmicBackground() {
  return (
    <div aria-hidden className="cosmic-bg">
      <div className="cosmic-nebula" />
      <div className="cosmic-stars" />
      <div className="cosmic-stars cosmic-stars--slow" />
      <div className="cosmic-shooting-star cosmic-shooting-star--a" />
      <div className="cosmic-shooting-star cosmic-shooting-star--b" />
    </div>
  );
}

